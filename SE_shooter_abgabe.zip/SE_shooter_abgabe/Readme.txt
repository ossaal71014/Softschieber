Sie steuern das blau Schiff mit den Pfeiltasten. 

Geschossen wird mit der linken Maustaste bzw. Strg.

Während des Spiels kann pausiert werden mit ESC. In diesem 
Menü kann auch neu gestartet werden.

Es sind alle Objekte im Spiel zu zerstören um Punkte zu erzielen, mit 
Ausnahme der kleinen grauen Schiffe. Diese sind als Zivilisten zu sehen,
d.h. es gibt Punktabzug wenn man diese angreift.